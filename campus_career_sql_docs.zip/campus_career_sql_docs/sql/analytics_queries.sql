-- Campus Career Intelligence Platform: Institutional Analytics
-- Assumed tables: students(student_id, student_name, branch, cgpa, ...)
--                 placements(placement_id, student_id, company_name,
--                            package_lpa, placement_status, placement_date)
-- Standardize status values (e.g. 'Placed') with your team's actual data.

-- 1. Branch-wise placement rate (each student counted once)
SELECT
    s.branch,
    COUNT(DISTINCT s.student_id) AS total_students,
    COUNT(DISTINCT s.student_id) FILTER (
        WHERE EXISTS (
            SELECT 1 FROM placements p
            WHERE p.student_id = s.student_id
              AND LOWER(p.placement_status) = 'placed'
        )
    ) AS placed_students,
    ROUND(
        100.0 * COUNT(DISTINCT s.student_id) FILTER (
            WHERE EXISTS (
                SELECT 1 FROM placements p
                WHERE p.student_id = s.student_id
                  AND LOWER(p.placement_status) = 'placed'
            )
        ) / NULLIF(COUNT(DISTINCT s.student_id), 0),
        2
    ) AS placement_rate_percent
FROM students s
GROUP BY s.branch
ORDER BY placement_rate_percent DESC NULLS LAST;

-- 2. Average CGPA of uniquely placed students
SELECT ROUND(AVG(s.cgpa), 2) AS average_cgpa_of_placed_students
FROM students s
WHERE EXISTS (
    SELECT 1 FROM placements p
    WHERE p.student_id = s.student_id
      AND LOWER(p.placement_status) = 'placed'
);

-- 3. Company-wise hiring and package summary
SELECT
    p.company_name,
    COUNT(DISTINCT p.student_id) AS students_hired,
    ROUND(AVG(p.package_lpa), 2) AS average_package_lpa,
    MAX(p.package_lpa) AS highest_package_lpa
FROM placements p
WHERE LOWER(p.placement_status) = 'placed'
GROUP BY p.company_name
ORDER BY students_hired DESC, p.company_name;

-- 4. Highest package by branch
SELECT
    s.branch,
    MAX(p.package_lpa) AS highest_package_lpa
FROM students s
JOIN placements p ON p.student_id = s.student_id
WHERE LOWER(p.placement_status) = 'placed'
GROUP BY s.branch
ORDER BY highest_package_lpa DESC NULLS LAST;

-- 5. Branch-wise average CGPA of placed students
SELECT
    s.branch,
    COUNT(DISTINCT s.student_id) AS placed_students,
    ROUND(AVG(s.cgpa), 2) AS average_cgpa
FROM students s
WHERE EXISTS (
    SELECT 1 FROM placements p
    WHERE p.student_id = s.student_id
      AND LOWER(p.placement_status) = 'placed'
)
GROUP BY s.branch
ORDER BY average_cgpa DESC NULLS LAST;

-- 6. Students with no successful placement record
SELECT s.student_id, s.student_name, s.branch, s.cgpa, s.skills
FROM students s
WHERE NOT EXISTS (
    SELECT 1 FROM placements p
    WHERE p.student_id = s.student_id
      AND LOWER(p.placement_status) = 'placed'
)
ORDER BY s.cgpa DESC NULLS LAST;

-- 7. Overall institutional placement summary
WITH student_status AS (
    SELECT
        s.student_id,
        EXISTS (
            SELECT 1 FROM placements p
            WHERE p.student_id = s.student_id
              AND LOWER(p.placement_status) = 'placed'
        ) AS is_placed
    FROM students s
)
SELECT
    COUNT(*) AS total_students,
    COUNT(*) FILTER (WHERE is_placed) AS placed_students,
    COUNT(*) FILTER (WHERE NOT is_placed) AS not_placed_students,
    ROUND(
        100.0 * COUNT(*) FILTER (WHERE is_placed) / NULLIF(COUNT(*), 0),
        2
    ) AS overall_placement_rate_percent
FROM student_status;

-- 8. Placement outcomes by graduation year and branch
SELECT
    s.graduation_year,
    s.branch,
    COUNT(*) AS total_students,
    COUNT(*) FILTER (
        WHERE EXISTS (
            SELECT 1 FROM placements p
            WHERE p.student_id = s.student_id
              AND LOWER(p.placement_status) = 'placed'
        )
    ) AS placed_students
FROM students s
GROUP BY s.graduation_year, s.branch
ORDER BY s.graduation_year, s.branch;
