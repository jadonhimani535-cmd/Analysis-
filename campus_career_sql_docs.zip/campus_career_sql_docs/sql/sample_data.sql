-- Sample records for local testing only. Not real institutional data.
INSERT INTO students (student_id, student_name, branch, cgpa, graduation_year, skills)
VALUES
(1, 'Aman', 'IT', 8.50, 2027, 'Python, SQL'),
(2, 'Priya', 'CSE', 9.00, 2027, 'Java, Python'),
(3, 'Rahul', 'IT', 7.50, 2027, 'SQL, HTML'),
(4, 'Neha', 'ECE', 8.00, 2027, 'Python, C'),
(5, 'Rohit', 'CSE', 6.80, 2027, 'Java, SQL')
ON CONFLICT (student_id) DO NOTHING;

INSERT INTO placements
(placement_id, student_id, company_name, package_lpa, placement_status, placement_date)
VALUES
(1, 1, 'TCS', 5.00, 'Placed', DATE '2026-08-10'),
(2, 2, 'Infosys', 6.00, 'Placed', DATE '2026-08-12'),
(3, 3, NULL, NULL, 'Not Placed', NULL),
(4, 4, 'Wipro', 4.50, 'Placed', DATE '2026-08-15'),
(5, 5, NULL, NULL, 'Not Placed', NULL)
ON CONFLICT (placement_id) DO NOTHING;
