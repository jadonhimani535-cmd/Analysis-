# Campus Career Intelligence Platform

A full-stack, data-driven platform concept for managing student profiles, recruitment activities and institutional placement analytics.

## Project modules

- **Student Profile:** academic details, branch, CGPA and technical skills.
- **Placement Management:** job opportunities, applications, recruitment drives and placement outcomes.
- **Analytics Dashboard:** institutional and branch-level placement reporting.
- **Machine Learning:** planned placement prediction, job recommendations and skill-gap analysis.
- **Role-based access:** Student, Recruiter and Admin roles.

## Technology stack

| Technology | Intended responsibility |
|---|---|
| React | Student, recruiter and admin interfaces |
| FastAPI | REST APIs and ML model serving |
| PostgreSQL | Users, students, jobs, applications and placement data |
| SQL | Data preparation and institutional analytics |
| Power BI | Placement and college analytics dashboards |
| Python | Backend services and machine-learning workflows |
| Git/GitHub | Version control and project documentation |

## Development phases

1. Authentication, database and student profiles.
2. Job and placement management.
3. React dashboards.
4. SQL analytics and Power BI reporting.
5. Placement prediction model.
6. Job recommendations and skill-gap analysis.
7. Deployment, testing and documentation.

## Institutional analytics contribution

The `sql/analytics_queries.sql` file contains PostgreSQL examples for:

1. Placement rate by branch.
2. Average CGPA of placed students.
3. Company-wise hiring and package summary.
4. Highest package by branch.
5. Branch-wise average CGPA of placed students.
6. Students without a successful placement record.
7. Overall institutional placement rate.
8. Placement outcomes by graduation year and branch.

### Database assumptions

The starter queries assume these tables and columns:

- `students(student_id, student_name, branch, cgpa, graduation_year, skills)`
- `placements(placement_id, student_id, company_name, package_lpa, placement_status, placement_date)`

**Important:** These are starter assumptions, not a claim about the repository's existing database. Before running the queries, compare them with the team's actual PostgreSQL models/schema and update table names, column names and status values. Do not create duplicate tables if equivalent tables already exist.

## SQL setup for local testing

1. Create a PostgreSQL database for the project.
2. If the team has no existing schema, run `sql/schema.sql`.
3. Run `sql/sample_data.sql` only in a test database; it contains fictional sample records.
4. Run selected queries from `sql/analytics_queries.sql`.
5. Validate results against known test records before using them in Power BI.

Example using `psql`:

```bash
psql -d campus_career_intelligence -f sql/schema.sql
psql -d campus_career_intelligence -f sql/sample_data.sql
psql -d campus_career_intelligence -f sql/analytics_queries.sql
```

## Power BI integration

The analytical query outputs can be used as data sources for Power BI visuals such as:

- Branch-wise placement rate (bar chart).
- Placed vs. not-placed students (card or donut chart).
- Company-wise hiring (bar chart).
- Average and highest package (cards).
- Average CGPA of placed students (card).

## Repository structure (suggested)

```text
cognicampus/
├── backend/
├── frontend/
├── sql/
│   ├── schema.sql
│   ├── sample_data.sql
│   └── analytics_queries.sql
└── README.md
```

Keep the repository's existing folder structure if it differs from this suggestion.

## Contribution scope

The analytics and documentation contribution covers analytical SQL query drafting, institutional metric definitions, SQL testing with sample data, and README documentation. Other application modules are developed by their respective team members.

## Limitations and future work

- Confirm final database schema and metric definitions with the project team.
- Add filters for academic year, branch and placement drive.
- Connect validated analytics to Power BI.
- Add automated tests for SQL metric calculations.
- Integrate ML predictions only after sufficient, appropriately prepared training data is available.

## Data and privacy

Use fictional or approved, anonymized student data for development and demonstrations. Do not commit passwords, API keys, database credentials or private student information to GitHub.
